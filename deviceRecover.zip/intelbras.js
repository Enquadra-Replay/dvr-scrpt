// Import required modules
const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3000;

function isValidDateTime(dateTime) {
    return /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(dateTime);
}

app.get('/cgi-bin/loadfile.cgi', (req, res) => {
    const { action, channel, startTime, endTime, subtype = 0, Types = 'dav' } = req.query;

    if (action !== 'startLoad') {
        return res.status(400).send('Invalid action. Use action=startLoad.');
    }
    if (!channel || !startTime || !endTime) {
        return res.status(400).send('Missing required parameters: channel, startTime, endTime.');
    }
    if (!isValidDateTime(startTime) || !isValidDateTime(endTime)) {
        return res.status(400).send('Invalid date format. Use yyyy-mm-dd hh:mm:ss.');
    }

    const filePath = path.join(__dirname, 'mockData', `channel${channel}_subtype${subtype}.${Types}`);

    if (!fs.existsSync(filePath)) {
        return res.status(404).send('File not found for the given parameters.');
    }

    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', `attachment; filename="channel${channel}_${startTime}_${endTime}.${Types}"`);

    const fileStream = fs.createReadStream(filePath);
    fileStream.pipe(res);

    fileStream.on('error', (err) => {
        console.error('File streaming error:', err);
        res.status(500).send('Internal server error while streaming the file.');
    });
});

app.listen(PORT, () => {
    console.log(`DVR server is running on http://localhost:${PORT}`);
});
